<?php

namespace Coinpal\Checkout\Block\Form;

class Checkout extends \Magento\Payment\Block\Form
{
    protected $_template = 'Coinpal_Checkout::form/pay.phtml';
}