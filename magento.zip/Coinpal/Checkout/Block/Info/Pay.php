<?php

namespace Coinpal\Checkout\Block\Info;

class Pay extends \Magento\Payment\Block\Info
{
    protected $_template = 'Coinpal_Checkout::info/pay.phtml';
}
